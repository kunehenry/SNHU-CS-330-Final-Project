#version 330 core

struct Material
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

struct LightSource
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float focalStrength;
    float specularIntensity;
};

#define TOTAL_LIGHTS 3

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

out vec4 outFragmentColor;

uniform bool bUseTexture = false;
uniform bool bUseLighting = false;
uniform vec4 objectColor = vec4(1.0);
uniform sampler2D objectTexture;
uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0);
uniform LightSource lightSources[TOTAL_LIGHTS];
uniform Material material;

// Used for the coffee volume: render a full carafe-shaped inner mesh,
// then discard every fragment above the horizontal liquid fill line.
uniform bool bUseHeightClip = false;
uniform float clipHeight = 1000.0;

void main()
{
    if (bUseHeightClip && fragmentPosition.y > clipHeight)
    {
        discard;
    }

    vec4 sampledColor = bUseTexture
        ? texture(objectTexture, fragmentTextureCoordinate * UVscale)
        : objectColor;

    if (!bUseLighting)
    {
        outFragmentColor = sampledColor;
        return;
    }

    vec3 normal = normalize(fragmentVertexNormal);
    vec3 viewDirection = normalize(viewPosition - fragmentPosition);

    vec3 ambientResult = material.ambientColor * material.ambientStrength * 0.45;
    vec3 diffuseResult = vec3(0.0);
    vec3 specularResult = vec3(0.0);

    for (int i = 0; i < TOTAL_LIGHTS; ++i)
    {
        vec3 toLight = lightSources[i].position - fragmentPosition;
        float distanceToLight = max(length(toLight), 0.001);
        vec3 lightDirection = toLight / distanceToLight;

        // Point-light falloff removes the harsh backsplash and counter hotspot.
        float attenuation = 1.0 /
            (1.0 + 0.015 * distanceToLight +
             0.003 * distanceToLight * distanceToLight);

        ambientResult += lightSources[i].ambientColor * material.ambientColor *
            material.ambientStrength;

        float diffuseImpact = max(dot(normal, lightDirection), 0.0);
        diffuseResult += attenuation * lightSources[i].diffuseColor *
            material.diffuseColor * diffuseImpact;

        vec3 reflectedDirection = reflect(-lightDirection, normal);
        float highlightExponent = max(
            2.0,
            0.5 * (material.shininess + lightSources[i].focalStrength));
        float specularComponent = pow(
            max(dot(viewDirection, reflectedDirection), 0.0),
            highlightExponent);

        specularResult += attenuation * lightSources[i].specularColor *
            material.specularColor * lightSources[i].specularIntensity *
            specularComponent;
    }

    // The texture is the surface albedo; specular reflection remains separate.
    vec3 linearColor = sampledColor.rgb * (ambientResult + diffuseResult) +
        specularResult;

    // Tone mapping retains pattern detail instead of clipping pale pixels.
    vec3 mappedColor = linearColor / (linearColor + vec3(1.0));
    mappedColor = pow(max(mappedColor, vec3(0.0)), vec3(1.0 / 2.2));

    outFragmentColor = vec4(mappedColor, sampledColor.a);
}
