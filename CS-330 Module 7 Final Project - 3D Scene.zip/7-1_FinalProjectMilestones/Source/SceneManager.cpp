///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

#include <iostream>

// shader uniform names
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();
	m_pShaderManager = nullptr;
	delete m_basicMeshes;
	m_basicMeshes = nullptr;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	if (m_loadedTextures >= 16)
	{
		std::cout << "Texture limit reached; could not load: " << filename << std::endl;
		return false;
	}

	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			glDeleteTextures(1, &textureID);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (nullptr != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (nullptr != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (nullptr != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (nullptr != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/*********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the texture image files used by the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool loaded = true;

	loaded = CreateGLTexture("textures/counter_marble.jpg", "counter") && loaded;
	loaded = CreateGLTexture("textures/black_plastic.jpg", "black_plastic") && loaded;
	loaded = CreateGLTexture("textures/brushed_metal.jpg", "brushed_metal") && loaded;
	loaded = CreateGLTexture("textures/blue_glass.png", "blue_glass") && loaded;
	loaded = CreateGLTexture("textures/coffee_liquid.jpg", "coffee") && loaded;
	loaded = CreateGLTexture("textures/ceramic_speckle.jpg", "ceramic") && loaded;
	loaded = CreateGLTexture("textures/wood_tray.jpg", "wood") && loaded;
	loaded = CreateGLTexture("textures/orange_peel.jpg", "orange") && loaded;
	loaded = CreateGLTexture("textures/backsplash_tile.jpg", "tile") && loaded;

	if (!loaded)
	{
		std::cout << "One or more scene textures failed to load." << std::endl;
	}

	BindGLTextures();
}


/*********************************************************
 *  DefineObjectMaterials()
 *
 *  This method configures the material settings for the scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL polishedMarble;
	polishedMarble.ambientColor = glm::vec3(0.50f, 0.47f, 0.43f);
	polishedMarble.ambientStrength = 0.28f;
	polishedMarble.diffuseColor = glm::vec3(0.74f, 0.70f, 0.64f);
	polishedMarble.specularColor = glm::vec3(0.09f, 0.085f, 0.08f);
	polishedMarble.shininess = 18.0f;
	polishedMarble.tag = "polished_marble";
	m_objectMaterials.push_back(polishedMarble);

	OBJECT_MATERIAL blackPlastic;
	blackPlastic.ambientColor = glm::vec3(0.22f, 0.22f, 0.22f);
	blackPlastic.ambientStrength = 0.38f;
	blackPlastic.diffuseColor = glm::vec3(0.38f, 0.38f, 0.38f);
	blackPlastic.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	blackPlastic.shininess = 28.0f;
	blackPlastic.tag = "black_plastic";
	m_objectMaterials.push_back(blackPlastic);

	OBJECT_MATERIAL brushedMetal;
	brushedMetal.ambientColor = glm::vec3(0.38f, 0.38f, 0.37f);
	brushedMetal.ambientStrength = 0.28f;
	brushedMetal.diffuseColor = glm::vec3(0.62f, 0.62f, 0.60f);
	brushedMetal.specularColor = glm::vec3(0.72f, 0.72f, 0.68f);
	brushedMetal.shininess = 44.0f;
	brushedMetal.tag = "brushed_metal";
	m_objectMaterials.push_back(brushedMetal);

	OBJECT_MATERIAL blueGlass;
	blueGlass.ambientColor = glm::vec3(0.16f, 0.22f, 0.30f);
	blueGlass.ambientStrength = 0.25f;
	blueGlass.diffuseColor = glm::vec3(0.30f, 0.42f, 0.56f);
	blueGlass.specularColor = glm::vec3(0.62f, 0.72f, 0.84f);
	blueGlass.shininess = 56.0f;
	blueGlass.tag = "blue_tinted_glass";
	m_objectMaterials.push_back(blueGlass);

	OBJECT_MATERIAL darkCoffee;
	darkCoffee.ambientColor = glm::vec3(0.25f, 0.12f, 0.05f);
	darkCoffee.ambientStrength = 0.25f;
	darkCoffee.diffuseColor = glm::vec3(0.40f, 0.20f, 0.08f);
	darkCoffee.specularColor = glm::vec3(0.24f, 0.18f, 0.12f);
	darkCoffee.shininess = 22.0f;
	darkCoffee.tag = "dark_coffee";
	m_objectMaterials.push_back(darkCoffee);

	OBJECT_MATERIAL indicatorLight;
	indicatorLight.ambientColor = glm::vec3(0.70f, 0.70f, 0.70f);
	indicatorLight.ambientStrength = 0.55f;
	indicatorLight.diffuseColor = glm::vec3(0.92f, 0.92f, 0.92f);
	indicatorLight.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
	indicatorLight.shininess = 24.0f;
	indicatorLight.tag = "indicator_light";
	m_objectMaterials.push_back(indicatorLight);

	OBJECT_MATERIAL ceramic;
	ceramic.ambientColor = glm::vec3(0.70f, 0.66f, 0.58f);
	ceramic.ambientStrength = 0.25f;
	ceramic.diffuseColor = glm::vec3(0.88f, 0.84f, 0.76f);
	ceramic.specularColor = glm::vec3(0.25f, 0.24f, 0.22f);
	ceramic.shininess = 32.0f;
	ceramic.tag = "ceramic";
	m_objectMaterials.push_back(ceramic);

	OBJECT_MATERIAL wood;
	wood.ambientColor = glm::vec3(0.46f, 0.26f, 0.10f);
	wood.ambientStrength = 0.28f;
	wood.diffuseColor = glm::vec3(0.75f, 0.45f, 0.20f);
	wood.specularColor = glm::vec3(0.12f, 0.08f, 0.04f);
	wood.shininess = 12.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL darkWood;
	darkWood.ambientColor = glm::vec3(0.22f, 0.10f, 0.035f);
	darkWood.ambientStrength = 0.30f;
	darkWood.diffuseColor = glm::vec3(0.38f, 0.18f, 0.06f);
	darkWood.specularColor = glm::vec3(0.08f, 0.05f, 0.025f);
	darkWood.shininess = 10.0f;
	darkWood.tag = "dark_wood";
	m_objectMaterials.push_back(darkWood);

	OBJECT_MATERIAL orangePeel;
	orangePeel.ambientColor = glm::vec3(0.70f, 0.25f, 0.03f);
	orangePeel.ambientStrength = 0.25f;
	orangePeel.diffuseColor = glm::vec3(1.00f, 0.50f, 0.04f);
	orangePeel.specularColor = glm::vec3(0.12f, 0.08f, 0.035f);
	orangePeel.shininess = 18.0f;
	orangePeel.tag = "orange_peel";
	m_objectMaterials.push_back(orangePeel);

	OBJECT_MATERIAL greenStem;
	greenStem.ambientColor = glm::vec3(0.12f, 0.25f, 0.06f);
	greenStem.ambientStrength = 0.30f;
	greenStem.diffuseColor = glm::vec3(0.24f, 0.48f, 0.12f);
	greenStem.specularColor = glm::vec3(0.05f, 0.06f, 0.03f);
	greenStem.shininess = 10.0f;
	greenStem.tag = "green_stem";
	m_objectMaterials.push_back(greenStem);

	OBJECT_MATERIAL tile;
	tile.ambientColor = glm::vec3(0.60f, 0.58f, 0.54f);
	tile.ambientStrength = 0.25f;
	tile.diffuseColor = glm::vec3(0.78f, 0.76f, 0.70f);
	tile.specularColor = glm::vec3(0.08f, 0.08f, 0.075f);
	tile.shininess = 18.0f;
	tile.tag = "tile";
	m_objectMaterials.push_back(tile);

	OBJECT_MATERIAL cupInterior;
	cupInterior.ambientColor = glm::vec3(0.30f, 0.24f, 0.18f);
	cupInterior.ambientStrength = 0.28f;
	cupInterior.diffuseColor = glm::vec3(0.42f, 0.34f, 0.25f);
	cupInterior.specularColor = glm::vec3(0.08f, 0.07f, 0.06f);
	cupInterior.shininess = 12.0f;
	cupInterior.tag = "cup_interior";
	m_objectMaterials.push_back(cupInterior);
}

/*********************************************************
 *  SetupSceneLights()
 *
 *  This method configures the light sources for the scene.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (nullptr == m_pShaderManager)
	{
		return;
	}

	// Warm point light above the coffee maker.
	m_pShaderManager->setVec3Value("lightSources[0].position", -3.5f, 8.5f, 5.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.12f, 0.105f, 0.085f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.95f, 0.82f, 0.68f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.70f, 0.62f, 0.54f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 28.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

	// Subtle blue point light provides the required colored source.
	m_pShaderManager->setVec3Value("lightSources[1].position", 7.5f, 5.5f, 3.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.025f, 0.035f, 0.055f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.20f, 0.28f, 0.42f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.16f, 0.24f, 0.40f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 24.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.18f);

	// Low-intensity front fill keeps the mug and carafe readable.
	m_pShaderManager->setVec3Value("lightSources[2].position", 1.5f, 4.0f, 8.5f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.025f, 0.022f, 0.020f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.22f, 0.18f, 0.15f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.12f, 0.10f, 0.08f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 20.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.12f);

	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/*********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes and textures in memory to support rendering.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// support surface
	m_basicMeshes->LoadPlaneMesh();

	// coffee maker parts
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh(0.13f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic shapes.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Draw the background and support surfaces first, followed by the
	// individual real-world objects that make up the kitchen arrangement.
	RenderBacksplash();
	RenderCountertop();
	RenderWoodenTray();
	RenderOrange();
	RenderCoffeeMug();
	RenderCoffeeMaker();
}

/***********************************************************
 *  RenderBacksplash()
 *
 *  Draws a vertical tiled plane behind the countertop.
 ***********************************************************/
void SceneManager::RenderBacksplash()
{
	glm::vec3 scaleXYZ = glm::vec3(24.0f, 1.0f, 8.4f);
	glm::vec3 positionXYZ = glm::vec3(0.0f, 4.2f, -3.65f);

	// The provided plane lies on the XZ plane. Rotating it 90 degrees
	// around X places it on the XY plane with its front facing the camera.
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.4f, 1.0f);
	SetShaderTexture("tile");
	SetShaderMaterial("tile");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderCountertop()
 *
 *  Draws the marble work surface and its visible front edge.
 ***********************************************************/
void SceneManager::RenderCountertop()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Marble work surface.
	scaleXYZ = glm::vec3(24.0f, 1.0f, 13.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.6f, 1.7f);
	SetShaderTexture("counter");
	SetShaderMaterial("polished_marble");
	m_basicMeshes->DrawPlaneMesh();

	// A thin box gives the countertop visible thickness from low camera angles.
	scaleXYZ = glm::vec3(24.0f, 0.36f, 0.45f);
	positionXYZ = glm::vec3(0.0f, -0.18f, 6.28f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.6f, 0.55f);
	SetShaderTexture("counter");
	SetShaderMaterial("polished_marble");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderWoodenTray()
 *
 *  Builds the serving tray from a floor, four raised rails,
 *  and two dark handle insets.
 ***********************************************************/
void SceneManager::RenderWoodenTray()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	const float trayCenterX = 5.0f;
	const float trayCenterZ = -0.35f;
	const float trayWidth = 5.20f;
	const float trayDepth = 3.45f;

	// Main tray floor.
	scaleXYZ = glm::vec3(trayWidth, 0.16f, trayDepth);
	positionXYZ = glm::vec3(trayCenterX, 0.08f, trayCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Slightly raised inner panel prevents the floor from looking completely flat.
	scaleXYZ = glm::vec3(4.72f, 0.035f, 2.98f);
	positionXYZ = glm::vec3(trayCenterX, 0.18f, trayCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(3.0f, 2.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Front rail.
	scaleXYZ = glm::vec3(trayWidth + 0.08f, 0.42f, 0.18f);
	positionXYZ = glm::vec3(trayCenterX, 0.30f, trayCenterZ + (trayDepth * 0.5f));
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(3.0f, 1.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Back rail.
	positionXYZ = glm::vec3(trayCenterX, 0.30f, trayCenterZ - (trayDepth * 0.5f));
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(3.0f, 1.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Left rail.
	scaleXYZ = glm::vec3(0.18f, 0.42f, trayDepth);
	positionXYZ = glm::vec3(trayCenterX - (trayWidth * 0.5f), 0.30f, trayCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Right rail.
	positionXYZ = glm::vec3(trayCenterX + (trayWidth * 0.5f), 0.30f, trayCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderTexture("wood");
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Dark front handle inset.
	scaleXYZ = glm::vec3(1.18f, 0.14f, 0.035f);
	positionXYZ = glm::vec3(
		trayCenterX,
		0.31f,
		trayCenterZ + (trayDepth * 0.5f) + 0.105f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("dark_wood");
	SetShaderColor(0.12f, 0.055f, 0.018f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Matching inset on the back rail.
	positionXYZ = glm::vec3(
		trayCenterX,
		0.31f,
		trayCenterZ - (trayDepth * 0.5f) - 0.105f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("dark_wood");
	SetShaderColor(0.12f, 0.055f, 0.018f, 1.0f);
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderOrange()
 *
 *  Builds the fruit from a textured sphere, a short stem,
 *  and a flattened leaf.
 ***********************************************************/
void SceneManager::RenderOrange()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// Slight nonuniform scaling gives the fruit a natural oval profile.
	// The smaller dimensions better match its size relative to the machine.
	scaleXYZ = glm::vec3(0.62f, 0.74f, 0.60f);
	positionXYZ = glm::vec3(5.55f, 0.94f, -0.25f);
	SetTransformations(scaleXYZ, 0.0f, -8.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderTexture("orange");
	SetShaderMaterial("orange_peel");
	m_basicMeshes->DrawSphereMesh();

	// Small green stem.
	scaleXYZ = glm::vec3(0.055f, 0.14f, 0.055f);
	positionXYZ = glm::vec3(5.55f, 1.66f, -0.25f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -8.0f, positionXYZ);
	SetShaderMaterial("green_stem");
	SetShaderColor(0.12f, 0.25f, 0.055f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Flattened sphere used as a simple low-polygon leaf.
	scaleXYZ = glm::vec3(0.17f, 0.035f, 0.085f);
	positionXYZ = glm::vec3(5.67f, 1.78f, -0.28f);
	SetTransformations(scaleXYZ, 8.0f, -25.0f, 16.0f, positionXYZ);
	SetShaderMaterial("green_stem");
	SetShaderColor(0.10f, 0.23f, 0.045f, 1.0f);
	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  RenderCoffeeMug()
 *
 *  Builds an open ceramic mug from a cylinder and two torus
 *  meshes. The handle intersects the cup wall so the hidden
 *  section is naturally removed by depth testing.
 ***********************************************************/
void SceneManager::RenderCoffeeMug()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	const float mugCenterX = 2.0f;
	const float mugCenterZ = 2.05f;

	// Handle loop. The torus is already vertical in the XY plane.
	scaleXYZ = glm::vec3(0.44f, 0.52f, 0.14f);
	positionXYZ = glm::vec3(mugCenterX + 0.60f, 0.62f, mugCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("ceramic");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();

	// Open cup body. The first Boolean disables the top cap.
	scaleXYZ = glm::vec3(0.62f, 1.20f, 0.62f);
	positionXYZ = glm::vec3(mugCenterX, 0.02f, mugCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.6f, 1.2f);
	SetShaderTexture("ceramic");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// Recessed dark disk suggests the shaded interior of an empty mug.
	scaleXYZ = glm::vec3(0.52f, 0.015f, 0.52f);
	positionXYZ = glm::vec3(mugCenterX, 1.15f, mugCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("cup_interior");
	SetShaderColor(0.30f, 0.25f, 0.19f, 1.0f);
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// Rounded lip at the top of the mug.
	scaleXYZ = glm::vec3(0.64f, 0.64f, 0.08f);
	positionXYZ = glm::vec3(mugCenterX, 1.22f, mugCenterZ);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("ceramic");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 *  RenderCoffeeMaker()
 *
 *  Builds the existing coffee maker from reusable box,
 *  cylinder, tapered-cylinder, sphere, and torus meshes.
 ***********************************************************/
void SceneManager::RenderCoffeeMaker()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	// -----------------------------------------------------------------
	// Coffee machine body
	// -----------------------------------------------------------------

	// bottom base tray
	scaleXYZ = glm::vec3(3.90f, 0.22f, 2.85f);
	positionXYZ = glm::vec3(-0.10f, 0.12f, 0.08f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.4f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// back body support
	scaleXYZ = glm::vec3(3.10f, 2.20f, 0.28f);
	positionXYZ = glm::vec3(-0.35f, 1.40f, -1.08f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.6f, 1.2f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// left frame support
	scaleXYZ = glm::vec3(0.95f, 2.38f, 2.25f);
	positionXYZ = glm::vec3(-1.50f, 1.42f, 0.02f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.2f, 1.5f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// right frame support
	scaleXYZ = glm::vec3(0.14f, 1.95f, 1.92f);
	positionXYZ = glm::vec3(1.12f, 1.18f, 0.06f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.3f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// left water reservoir
	scaleXYZ = glm::vec3(0.62f, 2.55f, 2.12f);
	positionXYZ = glm::vec3(-2.28f, 1.32f, 0.02f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.6f);
	SetShaderTexture("blue_glass");
	SetShaderMaterial("blue_tinted_glass");
	m_basicMeshes->DrawBoxMesh();

	// water level gauge strip
	scaleXYZ = glm::vec3(0.04f, 1.92f, 0.05f);
	positionXYZ = glm::vec3(-1.95f, 1.28f, 0.98f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("blue_glass");
	SetShaderMaterial("blue_tinted_glass");
	m_basicMeshes->DrawBoxMesh();

	// top machine housing
	scaleXYZ = glm::vec3(3.55f, 0.78f, 2.20f);
	positionXYZ = glm::vec3(-0.30f, 2.68f, 0.14f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// front control housing under top section
	scaleXYZ = glm::vec3(3.00f, 0.65f, 1.48f);
	positionXYZ = glm::vec3(-0.18f, 1.96f, 0.62f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.7f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawBoxMesh();

	// front control panel face
	scaleXYZ = glm::vec3(1.18f, 0.28f, 0.06f);
	positionXYZ = glm::vec3(0.20f, 1.92f, 1.39f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("brushed_metal");
	SetShaderMaterial("brushed_metal");
	m_basicMeshes->DrawBoxMesh();

	// small display window
	scaleXYZ = glm::vec3(0.45f, 0.12f, 0.05f);
	positionXYZ = glm::vec3(0.52f, 2.88f, 1.29f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("blue_glass");
	SetShaderMaterial("blue_tinted_glass");
	m_basicMeshes->DrawBoxMesh();

	// lid seam accent on the top housing
	scaleXYZ = glm::vec3(2.75f, 0.03f, 1.70f);
	positionXYZ = glm::vec3(-0.28f, 3.08f, 0.18f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.5f, 1.0f);
	SetShaderTexture("brushed_metal");
	SetShaderMaterial("brushed_metal");
	m_basicMeshes->DrawBoxMesh();

	// -----------------------------------------------------------------
	// Brew head and basket area
	// -----------------------------------------------------------------

	// brew basket holder
	scaleXYZ = glm::vec3(0.78f, 0.20f, 0.78f);
	positionXYZ = glm::vec3(0.02f, 1.58f, 0.66f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawCylinderMesh();

	// tapered funnel under brew basket
	scaleXYZ = glm::vec3(0.56f, 0.20f, 0.56f);
	positionXYZ = glm::vec3(0.02f, 1.40f, 0.66f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// brew ring accent
	scaleXYZ = glm::vec3(0.36f, 0.36f, 0.36f);
	positionXYZ = glm::vec3(0.02f, 1.30f, 0.66f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("brushed_metal");
	SetShaderMaterial("brushed_metal");
	m_basicMeshes->DrawTorusMesh();

	// drip nozzle
	scaleXYZ = glm::vec3(0.07f, 0.16f, 0.07f);
	positionXYZ = glm::vec3(0.02f, 1.20f, 0.66f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("brushed_metal");
	SetShaderMaterial("brushed_metal");
	m_basicMeshes->DrawCylinderMesh();

	// -----------------------------------------------------------------
	// Warming plate and carafe
	// -----------------------------------------------------------------

	// warming plate
	scaleXYZ = glm::vec3(2.20f, 0.08f, 1.62f);
	positionXYZ = glm::vec3(0.22f, 0.26f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.3f, 1.0f);
	SetShaderTexture("brushed_metal");
	SetShaderMaterial("brushed_metal");
	m_basicMeshes->DrawBoxMesh();

	// Coffee volume inside the carafe.  The liquid uses a second,
	// slightly smaller tapered cylinder so its walls follow the shape
	// of the glass instead of appearing as only a floating flat disk.
	// The shader clips this full-height inner mesh at a horizontal fill
	// line, and the thin cylinder below closes the liquid with a flat top.
	const float coffeeFillHeight = 0.90f;
	m_pShaderManager->setIntValue("bUseHeightClip", true);
	m_pShaderManager->setFloatValue("clipHeight", coffeeFillHeight);

	scaleXYZ = glm::vec3(0.90f, 0.90f, 0.84f);
	positionXYZ = glm::vec3(0.05f, 0.44f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee");
	SetShaderMaterial("dark_coffee");
	m_basicMeshes->DrawTaperedCylinderMesh(false, true, true);

	// Restore normal rendering before drawing the remaining objects.
	m_pShaderManager->setIntValue("bUseHeightClip", false);

	// Flat upper surface of the coffee.  Its radius matches the clipped
	// tapered body at the fill height, eliminating the former overhanging
	// disk appearance.
	scaleXYZ = glm::vec3(0.69f, 0.012f, 0.63f);
	positionXYZ = glm::vec3(0.05f, coffeeFillHeight - 0.004f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee");
	SetShaderMaterial("dark_coffee");
	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// neck collar
	scaleXYZ = glm::vec3(0.28f, 0.16f, 0.28f);
	positionXYZ = glm::vec3(0.05f, 1.22f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawCylinderMesh();

	// lid
	scaleXYZ = glm::vec3(0.48f, 0.09f, 0.48f);
	positionXYZ = glm::vec3(0.05f, 1.37f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawCylinderMesh();

	// Carafe handle. Keep every handle part on the carafe centerline so the
	// upper arm, lower arm, and curved grip remain aligned from the front.
	// The grip is also pulled closer to the glass for a more realistic depth.
	const float handleCenterX = 0.05f;
	const float handleCenterY = 0.85f;
	const float handleCenterZ = 1.55f;
	const float handleTopY = 1.19f;
	const float handleBottomY = 0.51f;
	const float upperWallZ = 1.13f;
	const float lowerWallZ = 1.44f;
	const float attachmentOverlap = 0.03f;

	// Rotating each cylinder 90 degrees around X points its local Y axis
	// outward along positive Z. The computed lengths make both arms overlap
	// the curved grip while their inner ends sit slightly inside the glass.
	const float upperArmLength =
		(handleCenterZ - upperWallZ) + attachmentOverlap;
	scaleXYZ = glm::vec3(0.085f, upperArmLength, 0.085f);
	positionXYZ = glm::vec3(handleCenterX, handleTopY, upperWallZ);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawCylinderMesh();

	const float lowerArmLength =
		(handleCenterZ - lowerWallZ) + attachmentOverlap;
	scaleXYZ = glm::vec3(0.085f, lowerArmLength, 0.085f);
	positionXYZ = glm::vec3(handleCenterX, handleBottomY, lowerWallZ);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawCylinderMesh();

	// Keep the original vertical opening, but reduce the outward Z radius
	// so the handle does not project as far beyond the carafe in side view.
	scaleXYZ = glm::vec3(0.34f, 0.22f, 0.26f);
	positionXYZ = glm::vec3(handleCenterX, handleCenterY, handleCenterZ);
	SetTransformations(scaleXYZ, 0.0f, 90.0f, 90.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("black_plastic");
	SetShaderMaterial("black_plastic");
	m_basicMeshes->DrawHalfTorusMesh();

	// -----------------------------------------------------------------
	// Small details
	// -----------------------------------------------------------------

	// power indicator light
	scaleXYZ = glm::vec3(0.055f, 0.055f, 0.055f);
	positionXYZ = glm::vec3(-0.12f, 1.95f, 1.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("indicator_light");
	SetShaderColor(0.76f, 0.15f, 0.12f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// ready indicator light
	positionXYZ = glm::vec3(0.10f, 1.95f, 1.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderMaterial("indicator_light");
	SetShaderColor(0.16f, 0.58f, 0.23f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// Draw the transparent glass last so all opaque scene geometry is
	// already present in the depth buffer.
	scaleXYZ = glm::vec3(0.96f, 0.96f, 0.90f);
	positionXYZ = glm::vec3(0.05f, 0.42f, 0.68f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetTextureUVScale(1.0f, 1.3f);
	SetShaderTexture("blue_glass");
	SetShaderMaterial("blue_tinted_glass");
	glEnable(GL_CULL_FACE);
	glDepthMask(GL_FALSE);
	m_basicMeshes->DrawTaperedCylinderMesh(false, false, true);
	glDepthMask(GL_TRUE);
	glDisable(GL_CULL_FACE);
}
